-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 29, 2025 at 08:13 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `goldapp_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `agta_awards`
--

CREATE TABLE `agta_awards` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `kicker` varchar(255) DEFAULT NULL,
  `kicker_ar` varchar(255) DEFAULT NULL,
  `title` varchar(255) NOT NULL,
  `title_ar` varchar(255) DEFAULT NULL,
  `description_top` text NOT NULL,
  `description_top_ar` text DEFAULT NULL,
  `description_bottom` text DEFAULT NULL,
  `description_bottom_ar` text DEFAULT NULL,
  `note` varchar(255) DEFAULT NULL,
  `note_ar` varchar(255) DEFAULT NULL,
  `drawing_image` varchar(255) DEFAULT NULL,
  `final_piece_image` varchar(255) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `agta_awards`
--

INSERT INTO `agta_awards` (`id`, `kicker`, `kicker_ar`, `title`, `title_ar`, `description_top`, `description_top_ar`, `description_bottom`, `description_bottom_ar`, `note`, `note_ar`, `drawing_image`, `final_piece_image`, `is_active`, `created_at`, `updated_at`) VALUES
(2, 'Showcase of Expertise & Artistry', 'معرض الخبرة والفن', 'My AGTA Spectrum Award-Winning Piece.', 'قطعتي الفائزة بجائزة AGTA Spectrum.', 'This prestigious 2017 award-winning piece featured a **Fabulous Golden South Seas Pearl** masterfully set in a combination of **Platinum and 18K gold**, accented with white and yellow diamonds.', 'تميزت هذه القطعة المرموقة الحائزة على جائزة عام 2017 بـ **لؤلؤة بحر الجنوب الذهبية الرائعة** مثبتة ببراعة في مزيج من **البلاتين والذهب عيار 18 قيراط**، ومزينة بالألماس الأبيض والأصفر.', 'This design showcases the high level of detail, precision, and artistry we bring to every CAD project, ensuring the final piece matches the original vision exactly.', 'يعرض هذا التصميم المستوى العالي من التفاصيل والدقة والفن الذي نقدمه لكل مشروع CAD، مما يضمن تطابق القطعة النهائية مع الرؤية الأصلية تماماً.', 'From initial concept and design to the final, finished masterpiece.', 'من المفهوم الأولي والتصميم إلى التحفة النهائية المكتملة.', 'https://picsum.photos/300/450?random=21&grayscale&blur=1', 'https://picsum.photos/500/500?random=22&sig=goldpiece', 1, '2025-11-23 11:52:56', '2025-11-23 11:52:56');

-- --------------------------------------------------------

--
-- Table structure for table `cache`
--

CREATE TABLE `cache` (
  `key` varchar(255) NOT NULL,
  `value` mediumtext NOT NULL,
  `expiration` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cache_locks`
--

CREATE TABLE `cache_locks` (
  `key` varchar(255) NOT NULL,
  `owner` varchar(255) NOT NULL,
  `expiration` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `carts`
--

CREATE TABLE `carts` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `session_id` varchar(255) DEFAULT NULL,
  `status` enum('active','abandoned','completed') NOT NULL DEFAULT 'active',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `carts`
--

INSERT INTO `carts` (`id`, `user_id`, `session_id`, `status`, `created_at`, `updated_at`) VALUES
(1, 1, NULL, 'active', '2025-11-23 13:28:52', '2025-11-23 13:28:52'),
(2, NULL, 'Zcgr9yWzXzhga6lyoyekBdUpwzLxBB4eTMLM10P2', 'active', '2025-11-23 13:32:17', '2025-11-23 13:32:17'),
(3, NULL, 'KxPYKjsn32hYkWX3ugQzetxULmKm1xCUfaEPH71x', 'active', '2025-11-23 13:37:35', '2025-11-23 13:37:35'),
(4, NULL, '63prD9zvceDLPlYPbBIIQg36tpxRkbzX3ZK5KYze', 'active', '2025-11-25 13:51:25', '2025-11-25 13:51:25'),
(5, NULL, 'XxgoAKNWjYueA5i7joBy60HbDE6GvZHziAgrz4jT', 'active', '2025-11-25 13:53:29', '2025-11-25 13:53:29'),
(6, NULL, 'l9TorZKNlYRALkjkwQVWuchqi8rTLpmbKxmac220', 'active', '2025-11-25 13:54:38', '2025-11-25 13:54:38'),
(7, NULL, '0tn9hpKTW3C9NuaY0bPCRlEKBJ1jLF6SMxuG2Lm4', 'active', '2025-11-25 14:17:31', '2025-11-25 14:17:31'),
(8, NULL, 'wW4ouJ2vL5KY5nA9N3aLwbrzgvm8Haks64RexMvq', 'active', '2025-11-25 14:28:24', '2025-11-25 14:28:24'),
(9, NULL, 'TyF2ccVbgXM2zWeAKG5ULNt3ErCylvoup8HGZaHz', 'active', '2025-11-25 14:48:52', '2025-11-25 14:48:52'),
(10, NULL, 'PqN1oze1RgJeja9lD7O6AsSF4G1lRbCnkKAaW9rb', 'active', '2025-11-25 14:58:03', '2025-11-25 14:58:03'),
(11, NULL, 'qfNQzWOqJXuy0qqrkAEukkJ6FnQnh8itr000GEgd', 'active', '2025-11-25 15:08:07', '2025-11-25 15:08:07'),
(12, NULL, 'br4Bs1Om8KxKH0DDkJaFDBJsmFFhlqpPRb5f38In', 'active', '2025-11-25 15:22:32', '2025-11-25 15:22:32'),
(13, NULL, 'wsqCy3rdnbIzo79w3kHXj5tPCa3QED4PItDKV73I', 'active', '2025-11-25 15:25:42', '2025-11-25 15:25:42');

-- --------------------------------------------------------

--
-- Table structure for table `cart_items`
--

CREATE TABLE `cart_items` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `cart_id` bigint(20) UNSIGNED NOT NULL,
  `design_id` bigint(20) UNSIGNED NOT NULL,
  `quantity` int(11) NOT NULL DEFAULT 1,
  `price` decimal(10,2) DEFAULT NULL,
  `customization` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`customization`)),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `cart_items`
--

INSERT INTO `cart_items` (`id`, `cart_id`, `design_id`, `quantity`, `price`, `customization`, `created_at`, `updated_at`) VALUES
(2, 2, 2, 1, 0.00, NULL, '2025-11-23 13:32:24', '2025-11-23 13:32:24'),
(3, 2, 3, 1, 0.00, NULL, '2025-11-23 13:32:59', '2025-11-23 13:32:59'),
(4, 2, 7, 1, 0.00, NULL, '2025-11-23 13:36:55', '2025-11-23 13:36:55'),
(5, 2, 4, 1, 0.00, NULL, '2025-11-23 13:37:36', '2025-11-23 13:37:36'),
(6, 2, 6, 1, 0.00, NULL, '2025-11-23 13:42:56', '2025-11-23 13:42:56'),
(14, 1, 7, 4, 0.00, NULL, '2025-11-25 14:27:32', '2025-11-25 14:29:21'),
(15, 1, 5, 1, 0.00, NULL, '2025-11-25 14:32:59', '2025-11-25 14:32:59'),
(16, 1, 4, 1, 0.00, NULL, '2025-11-25 14:33:29', '2025-11-25 14:33:29'),
(17, 1, 8, 1, 0.00, NULL, '2025-11-25 14:48:16', '2025-11-25 14:48:16'),
(18, 1, 6, 1, 0.00, NULL, '2025-11-25 14:48:21', '2025-11-25 14:48:21'),
(19, 13, 5, 3, 0.00, NULL, '2025-11-25 15:27:38', '2025-11-25 15:27:47'),
(20, 13, 4, 1, 0.00, NULL, '2025-11-25 15:27:40', '2025-11-25 15:27:40');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name_ar` varchar(100) NOT NULL,
  `name_en` varchar(100) NOT NULL,
  `slug` varchar(120) NOT NULL,
  `data_filter` varchar(50) NOT NULL COMMENT 'Used for frontend filtering, e.g., rings, bridal',
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name_ar`, `name_en`, `slug`, `data_filter`, `is_active`, `created_at`, `updated_at`) VALUES
(1, 'مجموعات الزفاف الفاخرة', 'Luxury Bridal Sets', 'luxury-bridal-sets', 'bridal', 1, '2025-11-15 17:30:09', '2025-11-19 21:01:58'),
(2, 'خواتم الخطوبة والزواج', 'Engagement & Bands', 'engagement-bands', 'rings', 1, '2025-11-15 17:30:09', '2025-11-15 17:30:09'),
(3, 'مجوهرات الأسماء العربية', 'Arabic Name Jewelryyyyyy', 'arabic-name-jewelry', 'names', 1, '2025-11-15 17:30:09', '2025-11-15 17:30:09'),
(4, 'خواتم الرجال والفضة', 'Men’s Rings & Silver', 'men-silver', 'silver', 1, '2025-11-15 17:30:09', '2025-11-15 17:30:09'),
(5, 'مجوهرات الأطفال والسحر', 'Kid\'s Jewelry & Charms', 'kids-jewelry', 'kids', 1, '2025-11-15 17:30:09', '2025-11-15 17:30:09');

-- --------------------------------------------------------

--
-- Table structure for table `designs`
--

CREATE TABLE `designs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `category_id` bigint(20) UNSIGNED NOT NULL,
  `name_ar` varchar(255) NOT NULL,
  `name_en` varchar(255) NOT NULL,
  `description_ar` text DEFAULT NULL,
  `cad_file_path` varchar(255) DEFAULT NULL COMMENT 'Path to the STL or 3DM file',
  `preview_image` varchar(255) DEFAULT NULL COMMENT 'Path to the visual image displayed on the card',
  `is_round_image` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'Flag to apply round styling to the image',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `designs`
--

INSERT INTO `designs` (`id`, `category_id`, `name_ar`, `name_en`, `description_ar`, `cad_file_path`, `preview_image`, `is_round_image`, `created_at`, `updated_at`) VALUES
(1, 1, 'مجموعات الزفاف الفاخرة', 'Luxury Bridal Sets', 'أطقم زفاف يمنية كاملة تشمل العقود والأساور والخواتم بأوزان وأبعاد متوازنة تمامًا.', NULL, 'https://picsum.photos/350/280?random=11&sig=bridal', 0, '2025-11-15 17:30:09', '2025-11-15 17:30:09'),
(2, 2, 'خواتم الخطوبة (CAD)', 'Engagement Rings (CAD)', 'تصاميم مفصلة لخواتم الخطوبة والماس مع إعداد دقيق للأحجار ومقاس مريح.', NULL, 'https://picsum.photos/350/280?random=14&sig=silver', 0, '2025-11-15 17:30:09', '2025-11-23 14:28:21'),
(3, 3, 'مجوهرات الأسماء العربية', 'Arabic Name Jewelry', 'تصاميم خط عربي معقدة للقلائد والأساور، مُحسّنة بالكامل لورش العمل بالليزر.', NULL, 'https://picsum.photos/350/280?random=13&sig=arabicname', 0, '2025-11-15 17:30:09', '2025-11-15 17:30:09'),
(4, 4, 'خواتم الرجال والفضة', 'Men’s Rings & Silver', 'نماذج ثلاثية الأبعاد دقيقة لخواتم وإكسسوارات الفضة للرجال بهيكل قوي وأشكال جذابة.', NULL, 'https://picsum.photos/350/280?random=14&sig=silver', 0, '2025-11-15 17:30:09', '2025-11-15 17:30:09'),
(5, 2, 'حلقات بافيه الحديثة', 'Modern Pave Bands', 'تصاميم بافيه حديثة والماس العنقودي، مُحسّنة لضمان تثبيت آمن للأحجار الصغيرة.', NULL, 'https://picsum.photos/350/280?random=15&sig=diamond', 0, '2025-11-15 17:30:09', '2025-11-15 17:30:09'),
(6, 5, 'مجوهرات الأطفال والسحر', 'Kid\'s Jewelry & Charms', 'نماذج ثلاثية الأبعاد مخصصة لإكسسوارات الأطفال الآمنة والخفيفة، بما في ذلك الأقراط والمعلقات.', NULL, 'https://picsum.photos/350/280?random=16&sig=kids', 0, '2025-11-15 17:30:09', '2025-11-15 17:30:09'),
(7, 1, 'الزخارف الذهبية التقليدية', 'Traditional Gold Motifs', 'تصاميم للمجوهرات الذهبية التقليدية الثقيلة والنقوش الكلاسيكية، مع الحفاظ على معايير CAD الحديثة.', NULL, 'https://picsum.photos/350/280?random=17&sig=traditional', 0, '2025-11-15 17:30:09', '2025-11-15 17:30:09'),
(8, 2, 'المعلقات الراقية', 'High-End Pendants', 'تصاميم لقلادات الماس والأحجار الكريمة الفاخرة، جاهزة للطباعة التقنية عالية الجودة.', NULL, 'https://picsum.photos/350/280?random=18&sig=luxury', 0, '2025-11-15 17:30:09', '2025-11-15 17:30:09');

-- --------------------------------------------------------

--
-- Table structure for table `design_details`
--

CREATE TABLE `design_details` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `design_id` bigint(20) UNSIGNED NOT NULL,
  `gold_karat` varchar(10) DEFAULT NULL,
  `estimated_weight` decimal(8,2) DEFAULT NULL COMMENT 'Weight in grams',
  `stone_count` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `design_details`
--

INSERT INTO `design_details` (`id`, `design_id`, `gold_karat`, `estimated_weight`, `stone_count`, `created_at`, `updated_at`) VALUES
(1, 1, '21k', 18.79, 42, '2025-11-15 17:30:09', '2025-11-15 17:30:09'),
(2, 2, '21k', 36.10, 7, '2025-11-15 17:30:09', '2025-11-15 17:30:09'),
(3, 3, '21k', 23.10, 13, '2025-11-15 17:30:09', '2025-11-15 17:30:09'),
(4, 4, '21k', 18.43, 32, '2025-11-15 17:30:09', '2025-11-15 17:30:09'),
(5, 5, '21k', 19.81, 30, '2025-11-15 17:30:09', '2025-11-15 17:30:09'),
(6, 6, '21k', 25.96, 18, '2025-11-15 17:30:09', '2025-11-15 17:30:09'),
(7, 7, '21k', 37.56, 31, '2025-11-15 17:30:09', '2025-11-15 17:30:09'),
(8, 8, '21k', 47.45, 17, '2025-11-15 17:30:09', '2025-11-15 17:30:09');

-- --------------------------------------------------------

--
-- Table structure for table `digital_prototyping_features`
--

CREATE TABLE `digital_prototyping_features` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `kicker_text` varchar(255) NOT NULL DEFAULT 'CAD & Production Planning',
  `main_title` varchar(255) NOT NULL DEFAULT 'Digital Prototyping: Visualize Your Masterpiece',
  `section_heading` varchar(255) NOT NULL DEFAULT 'From Sketch to Solid File',
  `section_heading_ar` varchar(255) DEFAULT NULL,
  `paragraph_1_en` text NOT NULL,
  `paragraph_2_en` text NOT NULL,
  `image_hero_url` varchar(255) NOT NULL,
  `image_detail_url` varchar(255) DEFAULT NULL,
  `image_production_url` varchar(255) DEFAULT NULL,
  `kicker_text_ar` varchar(255) DEFAULT NULL,
  `main_title_ar` varchar(255) DEFAULT NULL,
  `paragraph_1_ar` text DEFAULT NULL,
  `paragraph_2_ar` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `digital_prototyping_features`
--

INSERT INTO `digital_prototyping_features` (`id`, `kicker_text`, `main_title`, `section_heading`, `section_heading_ar`, `paragraph_1_en`, `paragraph_2_en`, `image_hero_url`, `image_detail_url`, `image_production_url`, `kicker_text_ar`, `main_title_ar`, `paragraph_1_ar`, `paragraph_2_ar`, `created_at`, `updated_at`) VALUES
(2, 'CAD & Production Planning', 'Digital Prototyping: Visualize Your Masterpiece', 'From Sketch to Solid File', 'من الرسم إلى الملف الصلب', 'We translate your creative vision into reality through three crucial digital stages. This meticulous process guarantees absolute accuracy, perfect geometry for casting, and empowers you to present a stunning, realistic preview to your client long before any physical gold is utilized.', 'The final delivery package includes all necessary manufacturing files (STL, 3DM) to ensure your local workshop can immediately commence printing or mold making without encountering any structural errors or design compromises.', 'https://picsum.photos/1200/600?random=88', 'https://picsum.photos/1200/600?random=89', 'https://picsum.photos/1200/600?random=90', 'تصميم CAD وتخطيط الإنتاج', 'النماذج الرقمية: تصور تحفتك الفنية', 'نترجم رؤيتك الإبداعية إلى واقع من خلال ثلاث مراحل رقمية حاسمة. تضمن هذه العملية الدقيقة دقة مطلقة، وهندسة مثالية للصب، وتمكنك من تقديم معاينة واقعية مذهلة لعميلك قبل وقت طويل من استخدام أي ذهب فعلي.', 'تتضمن حزمة التسليم النهائية جميع ملفات التصنيع الضرورية (STL، 3DM) لضمان أن ورشتك المحلية يمكنها البدء فوراً في الطباعة أو صنع القوالب دون مواجهة أي أخطاء هيكلية أو تنازلات في التصميم.', '2025-11-23 13:14:39', '2025-11-23 13:14:39');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `jobs`
--

CREATE TABLE `jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `queue` varchar(255) NOT NULL,
  `payload` longtext NOT NULL,
  `attempts` tinyint(3) UNSIGNED NOT NULL,
  `reserved_at` int(10) UNSIGNED DEFAULT NULL,
  `available_at` int(10) UNSIGNED NOT NULL,
  `created_at` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `job_batches`
--

CREATE TABLE `job_batches` (
  `id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `total_jobs` int(11) NOT NULL,
  `pending_jobs` int(11) NOT NULL,
  `failed_jobs` int(11) NOT NULL,
  `failed_job_ids` longtext NOT NULL,
  `options` mediumtext DEFAULT NULL,
  `cancelled_at` int(11) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `finished_at` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '0001_01_01_000000_create_users_table', 1),
(2, '0001_01_01_000001_create_cache_table', 1),
(3, '0001_01_01_000002_create_jobs_table', 1),
(4, '2025_11_15_202621_create_categories_table', 2),
(5, '2025_11_15_202626_create_designs_table', 2),
(6, '2025_11_15_202631_create_design_details_table', 2),
(7, '2025_11_15_202924_insert_initial_design_data', 3),
(8, '2025_11_15_203942_create_slider_images_table', 4),
(9, '2025_11_15_204029_insert_initial_slider_data', 5),
(10, '2025_11_15_205148_create_workflows_table', 6),
(11, '2025_11_15_205204_create_workflow_phases_table', 6),
(12, '2025_11_15_205446_insert_initial_workflow_data', 7),
(13, '2025_11_15_210405_create_digital_prototyping_features_tabl', 8),
(14, '2025_11_15_210622_insert_digital_prototyping_feature_data', 8),
(15, '2025_11_23_143938_create_agta_awards_table', 9),
(16, '2025_11_23_145047_add_ar_fields_to_agta_awards_table', 10),
(17, '2025_11_23_150301_add_ar_fields_to_workflows_table', 11),
(18, '2025_11_23_150305_add_ar_fields_to_workflow_phases_table', 11),
(19, '2025_11_23_160257_add_section_heading_ar_to_digital_prototyping_features', 12),
(20, '2025_11_23_162050_create_carts_table', 13),
(21, '2025_11_23_162058_create_cart_items_table', 13);

-- --------------------------------------------------------

--
-- Table structure for table `password_reset_tokens`
--

CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `sessions`
--

CREATE TABLE `sessions` (
  `id` varchar(255) NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `payload` longtext NOT NULL,
  `last_activity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sessions`
--

INSERT INTO `sessions` (`id`, `user_id`, `ip_address`, `user_agent`, `payload`, `last_activity`) VALUES
('0tn9hpKTW3C9NuaY0bPCRlEKBJ1jLF6SMxuG2Lm4', NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiZzFsN3dMSkxrNEl5U0JWSkhRZTJSbndxdkhxTWhMZXZLZ1NYUlczbCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MzI6Imh0dHA6Ly9sb2NhbGhvc3Q6NzAwMC9jYXJ0L2l0ZW1zIjtzOjU6InJvdXRlIjtzOjEwOiJjYXJ0Lml0ZW1zIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==', 1764092587),
('br4Bs1Om8KxKH0DDkJaFDBJsmFFhlqpPRb5f38In', NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiUTYzejM4bnZUbFpkRUFScWh3bk9zcWFpdVRsWWxjY0ZLYXV4cVRoaiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MzI6Imh0dHA6Ly8xMjcuMC4wLjE6NzAwMC9jYXJ0L2l0ZW1zIjtzOjU6InJvdXRlIjtzOjEwOiJjYXJ0Lml0ZW1zIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==', 1764094961),
('CJGbyAK9zMWXCHrpxBeSFAQM7qbXa7x2mtYdusSB', 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'YTo2OntzOjY6Il90b2tlbiI7czo0MDoibHVOMXB6Qzc5VnBCekl6bHJYb2htczVicVhtVTl3dG93OE40NjFoViI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6Mjc6Imh0dHA6Ly8xMjcuMC4wLjE6NzAwMC9hZG1pbiI7czo1OiJyb3V0ZSI7czozMDoiZmlsYW1lbnQuYWRtaW4ucGFnZXMuZGFzaGJvYXJkIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319czozOiJ1cmwiO2E6MDp7fXM6NTA6ImxvZ2luX3dlYl81OWJhMzZhZGRjMmIyZjk0MDE1ODBmMDE0YzdmNThlYTRlMzA5ODlkIjtpOjE7czoxNzoicGFzc3dvcmRfaGFzaF93ZWIiO3M6NjA6IiQyeSQxMiRrd3kzM1dLUmVXdi82alJyNmFDcWIuZUFxckNEWVVOd1BKRVRtaWhSTGZ4Y1J1VGxvbTVMQyI7fQ==', 1764089692),
('f33DuBybi66SvBPn8dmshdSduqf3TUsrWmDprRVw', 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'YTo4OntzOjY6Il90b2tlbiI7czo0MDoiS3h0SklONVJqT3QzWnpCVXF5czh2YjFnNEQ2TVBhMWVuU1k0aFJBVSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MzI6Imh0dHA6Ly8xMjcuMC4wLjE6NzAwMC9jYXJ0L2l0ZW1zIjtzOjU6InJvdXRlIjtzOjEwOiJjYXJ0Lml0ZW1zIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319czozOiJ1cmwiO2E6MDp7fXM6NTA6ImxvZ2luX3dlYl81OWJhMzZhZGRjMmIyZjk0MDE1ODBmMDE0YzdmNThlYTRlMzA5ODlkIjtpOjE7czoxNzoicGFzc3dvcmRfaGFzaF93ZWIiO3M6NjA6IiQyeSQxMiRrd3kzM1dLUmVXdi82alJyNmFDcWIuZUFxckNEWVVOd1BKRVRtaWhSTGZ4Y1J1VGxvbTVMQyI7czo2OiJ0YWJsZXMiO2E6Mzp7czo0MDoiMTNkMzM1ZDAzYmVhMDhmNzZlNzBlNzExNjVlNTcxNWJfY29sdW1ucyI7YTo2OntpOjA7YTo3OntzOjQ6InR5cGUiO3M6NjoiY29sdW1uIjtzOjQ6Im5hbWUiO3M6MTA6ImltYWdlX3BhdGgiO3M6NToibGFiZWwiO3M6NToiSW1hZ2UiO3M6ODoiaXNIaWRkZW4iO2I6MDtzOjk6ImlzVG9nZ2xlZCI7YjoxO3M6MTI6ImlzVG9nZ2xlYWJsZSI7YjowO3M6MjQ6ImlzVG9nZ2xlZEhpZGRlbkJ5RGVmYXVsdCI7Tjt9aToxO2E6Nzp7czo0OiJ0eXBlIjtzOjY6ImNvbHVtbiI7czo0OiJuYW1lIjtzOjg6InRpdGxlX2FyIjtzOjU6ImxhYmVsIjtzOjU6IlRpdGxlIjtzOjg6ImlzSGlkZGVuIjtiOjA7czo5OiJpc1RvZ2dsZWQiO2I6MTtzOjEyOiJpc1RvZ2dsZWFibGUiO2I6MDtzOjI0OiJpc1RvZ2dsZWRIaWRkZW5CeURlZmF1bHQiO047fWk6MjthOjc6e3M6NDoidHlwZSI7czo2OiJjb2x1bW4iO3M6NDoibmFtZSI7czoxMDoiY2FwdGlvbl9hciI7czo1OiJsYWJlbCI7czo3OiJDYXB0aW9uIjtzOjg6ImlzSGlkZGVuIjtiOjA7czo5OiJpc1RvZ2dsZWQiO2I6MTtzOjEyOiJpc1RvZ2dsZWFibGUiO2I6MDtzOjI0OiJpc1RvZ2dsZWRIaWRkZW5CeURlZmF1bHQiO047fWk6MzthOjc6e3M6NDoidHlwZSI7czo2OiJjb2x1bW4iO3M6NDoibmFtZSI7czo4OiJsaW5rX3VybCI7czo1OiJsYWJlbCI7czozOiJVUkwiO3M6ODoiaXNIaWRkZW4iO2I6MDtzOjk6ImlzVG9nZ2xlZCI7YjoxO3M6MTI6ImlzVG9nZ2xlYWJsZSI7YjoxO3M6MjQ6ImlzVG9nZ2xlZEhpZGRlbkJ5RGVmYXVsdCI7YjowO31pOjQ7YTo3OntzOjQ6InR5cGUiO3M6NjoiY29sdW1uIjtzOjQ6Im5hbWUiO3M6MTA6InNvcnRfb3JkZXIiO3M6NToibGFiZWwiO3M6NToiT3JkZXIiO3M6ODoiaXNIaWRkZW4iO2I6MDtzOjk6ImlzVG9nZ2xlZCI7YjoxO3M6MTI6ImlzVG9nZ2xlYWJsZSI7YjowO3M6MjQ6ImlzVG9nZ2xlZEhpZGRlbkJ5RGVmYXVsdCI7Tjt9aTo1O2E6Nzp7czo0OiJ0eXBlIjtzOjY6ImNvbHVtbiI7czo0OiJuYW1lIjtzOjk6ImlzX2FjdGl2ZSI7czo1OiJsYWJlbCI7czo2OiJBY3RpdmUiO3M6ODoiaXNIaWRkZW4iO2I6MDtzOjk6ImlzVG9nZ2xlZCI7YjoxO3M6MTI6ImlzVG9nZ2xlYWJsZSI7YjowO3M6MjQ6ImlzVG9nZ2xlZEhpZGRlbkJ5RGVmYXVsdCI7Tjt9fXM6NDA6IjEwN2M1ZDQ0NDQ4MDIyMTJkYzUwMjliZmVmNDNkMzIxX2NvbHVtbnMiO2E6Njp7aTowO2E6Nzp7czo0OiJ0eXBlIjtzOjY6ImNvbHVtbiI7czo0OiJuYW1lIjtzOjEzOiJwcmV2aWV3X2ltYWdlIjtzOjU6ImxhYmVsIjtzOjA6IiI7czo4OiJpc0hpZGRlbiI7YjowO3M6OToiaXNUb2dnbGVkIjtiOjE7czoxMjoiaXNUb2dnbGVhYmxlIjtiOjA7czoyNDoiaXNUb2dnbGVkSGlkZGVuQnlEZWZhdWx0IjtOO31pOjE7YTo3OntzOjQ6InR5cGUiO3M6NjoiY29sdW1uIjtzOjQ6Im5hbWUiO3M6NzoibmFtZV9hciI7czo1OiJsYWJlbCI7czoxMzoiTmFtZSAoQXJhYmljKSI7czo4OiJpc0hpZGRlbiI7YjowO3M6OToiaXNUb2dnbGVkIjtiOjE7czoxMjoiaXNUb2dnbGVhYmxlIjtiOjA7czoyNDoiaXNUb2dnbGVkSGlkZGVuQnlEZWZhdWx0IjtOO31pOjI7YTo3OntzOjQ6InR5cGUiO3M6NjoiY29sdW1uIjtzOjQ6Im5hbWUiO3M6NzoibmFtZV9lbiI7czo1OiJsYWJlbCI7czoxNDoiTmFtZSAoRW5nbGlzaCkiO3M6ODoiaXNIaWRkZW4iO2I6MDtzOjk6ImlzVG9nZ2xlZCI7YjoxO3M6MTI6ImlzVG9nZ2xlYWJsZSI7YjowO3M6MjQ6ImlzVG9nZ2xlZEhpZGRlbkJ5RGVmYXVsdCI7Tjt9aTozO2E6Nzp7czo0OiJ0eXBlIjtzOjY6ImNvbHVtbiI7czo0OiJuYW1lIjtzOjE2OiJjYXRlZ29yeS5uYW1lX2FyIjtzOjU6ImxhYmVsIjtzOjg6IkNhdGVnb3J5IjtzOjg6ImlzSGlkZGVuIjtiOjA7czo5OiJpc1RvZ2dsZWQiO2I6MTtzOjEyOiJpc1RvZ2dsZWFibGUiO2I6MDtzOjI0OiJpc1RvZ2dsZWRIaWRkZW5CeURlZmF1bHQiO047fWk6NDthOjc6e3M6NDoidHlwZSI7czo2OiJjb2x1bW4iO3M6NDoibmFtZSI7czoxMDoiY3JlYXRlZF9hdCI7czo1OiJsYWJlbCI7czoxMDoiQ3JlYXRlZCBhdCI7czo4OiJpc0hpZGRlbiI7YjowO3M6OToiaXNUb2dnbGVkIjtiOjA7czoxMjoiaXNUb2dnbGVhYmxlIjtiOjE7czoyNDoiaXNUb2dnbGVkSGlkZGVuQnlEZWZhdWx0IjtiOjE7fWk6NTthOjc6e3M6NDoidHlwZSI7czo2OiJjb2x1bW4iO3M6NDoibmFtZSI7czoxMDoidXBkYXRlZF9hdCI7czo1OiJsYWJlbCI7czoxMDoiVXBkYXRlZCBhdCI7czo4OiJpc0hpZGRlbiI7YjowO3M6OToiaXNUb2dnbGVkIjtiOjA7czoxMjoiaXNUb2dnbGVhYmxlIjtiOjE7czoyNDoiaXNUb2dnbGVkSGlkZGVuQnlEZWZhdWx0IjtiOjE7fX1zOjQwOiIyMzZjMTgwNGRmNmQ2NTgwMWJlYmJkYzlmOWU1MmE1ZV9jb2x1bW5zIjthOjg6e2k6MDthOjc6e3M6NDoidHlwZSI7czo2OiJjb2x1bW4iO3M6NDoibmFtZSI7czo2OiJraWNrZXIiO3M6NToibGFiZWwiO3M6NjoiS2lja2VyIjtzOjg6ImlzSGlkZGVuIjtiOjA7czo5OiJpc1RvZ2dsZWQiO2I6MTtzOjEyOiJpc1RvZ2dsZWFibGUiO2I6MDtzOjI0OiJpc1RvZ2dsZWRIaWRkZW5CeURlZmF1bHQiO047fWk6MTthOjc6e3M6NDoidHlwZSI7czo2OiJjb2x1bW4iO3M6NDoibmFtZSI7czo1OiJ0aXRsZSI7czo1OiJsYWJlbCI7czo1OiJUaXRsZSI7czo4OiJpc0hpZGRlbiI7YjowO3M6OToiaXNUb2dnbGVkIjtiOjE7czoxMjoiaXNUb2dnbGVhYmxlIjtiOjA7czoyNDoiaXNUb2dnbGVkSGlkZGVuQnlEZWZhdWx0IjtOO31pOjI7YTo3OntzOjQ6InR5cGUiO3M6NjoiY29sdW1uIjtzOjQ6Im5hbWUiO3M6MTM6ImRyYXdpbmdfaW1hZ2UiO3M6NToibGFiZWwiO3M6MTM6IkRyYXdpbmcgSW1hZ2UiO3M6ODoiaXNIaWRkZW4iO2I6MDtzOjk6ImlzVG9nZ2xlZCI7YjoxO3M6MTI6ImlzVG9nZ2xlYWJsZSI7YjowO3M6MjQ6ImlzVG9nZ2xlZEhpZGRlbkJ5RGVmYXVsdCI7Tjt9aTozO2E6Nzp7czo0OiJ0eXBlIjtzOjY6ImNvbHVtbiI7czo0OiJuYW1lIjtzOjE3OiJmaW5hbF9waWVjZV9pbWFnZSI7czo1OiJsYWJlbCI7czoxNzoiRmluYWwgUGllY2UgSW1hZ2UiO3M6ODoiaXNIaWRkZW4iO2I6MDtzOjk6ImlzVG9nZ2xlZCI7YjoxO3M6MTI6ImlzVG9nZ2xlYWJsZSI7YjowO3M6MjQ6ImlzVG9nZ2xlZEhpZGRlbkJ5RGVmYXVsdCI7Tjt9aTo0O2E6Nzp7czo0OiJ0eXBlIjtzOjY6ImNvbHVtbiI7czo0OiJuYW1lIjtzOjE1OiJkZXNjcmlwdGlvbl90b3AiO3M6NToibGFiZWwiO3M6MTU6IkRlc2NyaXB0aW9uIFRvcCI7czo4OiJpc0hpZGRlbiI7YjowO3M6OToiaXNUb2dnbGVkIjtiOjE7czoxMjoiaXNUb2dnbGVhYmxlIjtiOjA7czoyNDoiaXNUb2dnbGVkSGlkZGVuQnlEZWZhdWx0IjtOO31pOjU7YTo3OntzOjQ6InR5cGUiO3M6NjoiY29sdW1uIjtzOjQ6Im5hbWUiO3M6MTg6ImRlc2NyaXB0aW9uX2JvdHRvbSI7czo1OiJsYWJlbCI7czoxODoiRGVzY3JpcHRpb24gQm90dG9tIjtzOjg6ImlzSGlkZGVuIjtiOjA7czo5OiJpc1RvZ2dsZWQiO2I6MTtzOjEyOiJpc1RvZ2dsZWFibGUiO2I6MDtzOjI0OiJpc1RvZ2dsZWRIaWRkZW5CeURlZmF1bHQiO047fWk6NjthOjc6e3M6NDoidHlwZSI7czo2OiJjb2x1bW4iO3M6NDoibmFtZSI7czo0OiJub3RlIjtzOjU6ImxhYmVsIjtzOjQ6Ik5vdGUiO3M6ODoiaXNIaWRkZW4iO2I6MDtzOjk6ImlzVG9nZ2xlZCI7YjoxO3M6MTI6ImlzVG9nZ2xlYWJsZSI7YjowO3M6MjQ6ImlzVG9nZ2xlZEhpZGRlbkJ5RGVmYXVsdCI7Tjt9aTo3O2E6Nzp7czo0OiJ0eXBlIjtzOjY6ImNvbHVtbiI7czo0OiJuYW1lIjtzOjk6ImlzX2FjdGl2ZSI7czo1OiJsYWJlbCI7czo5OiJJcyBBY3RpdmUiO3M6ODoiaXNIaWRkZW4iO2I6MDtzOjk6ImlzVG9nZ2xlZCI7YjoxO3M6MTI6ImlzVG9nZ2xlYWJsZSI7YjowO3M6MjQ6ImlzVG9nZ2xlZEhpZGRlbkJ5RGVmYXVsdCI7Tjt9fX1zOjY6ImxvY2FsZSI7czoyOiJhciI7fQ==', 1764094911),
('PqN1oze1RgJeja9lD7O6AsSF4G1lRbCnkKAaW9rb', NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiRDBGZld6Nk1RN0dYUFFQcjE4YXplUmpmVnZBWGpZSEhwYTE5WHVpQSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MzI6Imh0dHA6Ly9sb2NhbGhvc3Q6NzAwMC9jYXJ0L2l0ZW1zIjtzOjU6InJvdXRlIjtzOjEwOiJjYXJ0Lml0ZW1zIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==', 1764093483),
('qfNQzWOqJXuy0qqrkAEukkJ6FnQnh8itr000GEgd', NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiU0RQMjFoNWZmVTRVZW5hSHJTckFhVnUxVGZmem5weHhwdjBBcENXcyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MzI6Imh0dHA6Ly9sb2NhbGhvc3Q6NzAwMC9jYXJ0L2l0ZW1zIjtzOjU6InJvdXRlIjtzOjEwOiJjYXJ0Lml0ZW1zIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==', 1764094087),
('TyF2ccVbgXM2zWeAKG5ULNt3ErCylvoup8HGZaHz', NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoieDNEV0RWa1B2a1ZNdmtNalY0aWlMdzRIUFZVamo3NlQyU0VvNEY4SCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MzI6Imh0dHA6Ly9sb2NhbGhvc3Q6NzAwMC9jYXJ0L2l0ZW1zIjtzOjU6InJvdXRlIjtzOjEwOiJjYXJ0Lml0ZW1zIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==', 1764092934),
('wsqCy3rdnbIzo79w3kHXj5tPCa3QED4PItDKV73I', NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiZFNLVnFFaU5BVjAxWWNMYlNqN0VCUG5BT2NycFFjRE1rUGNiSjhOdSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MzI6Imh0dHA6Ly8xMjcuMC4wLjE6NzAwMC9jYXJ0L2l0ZW1zIjtzOjU6InJvdXRlIjtzOjEwOiJjYXJ0Lml0ZW1zIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==', 1764095268),
('wW4ouJ2vL5KY5nA9N3aLwbrzgvm8Haks64RexMvq', NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiSEt3bWNPUE9PTUxBV2J4UGN0eEdOU0NWZWtQNkhVTkI3ZFVCenZueiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MzI6Imh0dHA6Ly9sb2NhbGhvc3Q6NzAwMC9jYXJ0L2l0ZW1zIjtzOjU6InJvdXRlIjtzOjEwOiJjYXJ0Lml0ZW1zIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==', 1764091728),
('XxgoAKNWjYueA5i7joBy60HbDE6GvZHziAgrz4jT', NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'YTo0OntzOjY6Il90b2tlbiI7czo0MDoicVdPTTcySXE0elJUZUpsbG1NZzdqcXppendoWEhWRm85bzV6MEtGZCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MzM6Imh0dHA6Ly8xMjcuMC4wLjE6NzAwMC9hZG1pbi9sb2dpbiI7czo1OiJyb3V0ZSI7czoyNToiZmlsYW1lbnQuYWRtaW4uYXV0aC5sb2dpbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fXM6MzoidXJsIjthOjE6e3M6ODoiaW50ZW5kZWQiO3M6Mjc6Imh0dHA6Ly8xMjcuMC4wLjE6NzAwMC9hZG1pbiI7fX0=', 1764089618);

-- --------------------------------------------------------

--
-- Table structure for table `slider_images`
--

CREATE TABLE `slider_images` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `image_path` varchar(255) NOT NULL,
  `alt_text` varchar(255) NOT NULL,
  `title_ar` varchar(150) DEFAULT NULL,
  `caption_ar` text DEFAULT NULL,
  `link_url` varchar(255) DEFAULT NULL,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `slider_images`
--

INSERT INTO `slider_images` (`id`, `image_path`, `alt_text`, `title_ar`, `caption_ar`, `link_url`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES
(1, 'https://picsum.photos/1200/600?random=11', 'High-End Diamond Necklace CAD', 'تصاميم مجوهرات مخصصة', 'نقدم نماذج CAD ثلاثية الأبعاد بجودة عالية تناسب الأسواق اليمنية.', '/designs', 10, 1, '2025-11-15 17:41:42', '2025-11-15 17:41:42'),
(2, 'https://picsum.photos/1200/600?random=22', 'Luxury Diamond Rings Collection', 'خواتم ماس فاخرة', 'اكتشف مجموعتنا الحصرية من خواتم الخطوبة بتصاميم عصرية.', '/collections?filter=rings', 20, 1, '2025-11-15 17:41:42', '2025-11-15 17:41:42'),
(3, 'https://picsum.photos/1200/600?random=33', 'Traditional Yemeni Gold Sets', 'أطقم ذهب تقليدية يمنية', 'تصاميم بأوزان مثالية ومعايير هندسية دقيقة لورش العمل المحلية.', '/collections?filter=bridal', 30, 1, '2025-11-15 17:41:42', '2025-11-15 17:41:42'),
(4, 'https://picsum.photos/1200/600?random=44', 'Detailed 3D Pave Setting Model', 'تقنية ترصيع البافيه الدقيقة', 'تفاصيل هندسية تضمن ثبات الأحجار الصغيرة وجودة المنتج النهائي.', '/details/pave-model', 40, 1, '2025-11-15 17:41:42', '2025-11-15 17:41:42'),
(5, 'https://picsum.photos/1200/600?random=55', 'Custom Arabic Calligraphy Jewelry', 'مجوهرات خط عربي فريدة', 'تصميمات أسماء ونقوش عربية جاهزة للقطع بالليزر بأقصى دقة.', '/collections?filter=names', 50, 1, '2025-11-15 17:41:42', '2025-11-15 17:41:42'),
(6, 'https://picsum.photos/1200/600?random=66', 'Gents Silver Ring with Stone CAD', 'خواتم فضة رجالية', 'موديلات عصرية وكلاسيكية لخواتم الفضة الرجالية والأحجار الكريمة.', '/collections?filter=silver', 60, 1, '2025-11-15 17:41:42', '2025-11-15 17:41:42'),
(7, 'https://picsum.photos/1200/600?random=77', 'Lightweight Kids Jewelry Models', 'تصاميم مجوهرات الأطفال', 'إكسسوارات خفيفة وآمنة للأطفال، أقراط ومعلقات بأسعار مناسبة.', '/collections?filter=kids', 70, 1, '2025-11-15 17:41:42', '2025-11-15 17:41:42'),
(8, 'https://picsum.photos/1200/600?random=88', 'High Polish Gold Bangle Design', 'أساور ذهبية لامعة', 'نماذج ثلاثية الأبعاد لأساور الذهب بتصميمات مريحة وتلميع عالي.', '/collections?filter=bridal', 80, 1, '2025-11-15 17:41:42', '2025-11-15 17:41:42'),
(9, 'https://picsum.photos/1200/600?random=99', 'Gemstone Cluster Ring CAD', 'خواتم مرصعة بالأحجار الكريمة', 'تصاميم عنقودية تجمع بين الذهب الأبيض والأحجار الملونة.', '/collections?filter=rings', 90, 1, '2025-11-15 17:41:42', '2025-11-15 17:41:42'),
(10, 'https://picsum.photos/1200/600?random=101', 'CAD Service Landing Page Banner', 'خدمة النمذجة المخصصة', 'أرسل لنا فكرتك، وسنتولى تحويلها إلى ملف CAD جاهز للتصنيع.', '/request-design', 100, 1, '2025-11-15 17:41:42', '2025-11-15 17:41:42');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'admin', 'admin@admin.com', NULL, '$2y$12$kwy33WKReWv/6jRr6aCqb.eAqrCDYUNwPJETmihRLfxcRuTlom5LC', NULL, '2025-11-18 18:34:32', '2025-11-18 18:34:32');

-- --------------------------------------------------------

--
-- Table structure for table `workflows`
--

CREATE TABLE `workflows` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `kicker` varchar(255) NOT NULL COMMENT 'Digital Precision from Concept to Production',
  `kicker_ar` varchar(255) DEFAULT NULL,
  `title` varchar(255) NOT NULL COMMENT 'Seamless 4-Step 3D Design Workflow',
  `title_ar` varchar(255) DEFAULT NULL,
  `description` text NOT NULL,
  `description_ar` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `workflows`
--

INSERT INTO `workflows` (`id`, `kicker`, `kicker_ar`, `title`, `title_ar`, `description`, `description_ar`, `created_at`, `updated_at`) VALUES
(3, 'DIGITAL PRECISION FROM CONCEPT TO PRODUCTION', 'دقة رقمية من المفهوم إلى الإنتاج', 'Seamless 4-Step 3D Design Workflow', 'سير عمل تصميم ثلاثي الأبعاد سلس من 4 خطوات', 'We ensure a clear and optimized digital workflow tailored to meet the needs of jewelry workshops and shops across Yemen. From initial concept to final casting files, we deliver the necessary speed and accuracy.', 'نضمن سير عمل رقمي واضح ومحسّن مصمم خصيصاً لتلبية احتياجات ورش ومحلات المجوهرات في جميع أنحاء اليمن. من المفهوم الأولي إلى ملفات الصب النهائية، نقدم السرعة والدقة اللازمة.', '2025-11-23 12:52:27', '2025-11-23 12:52:27');

-- --------------------------------------------------------

--
-- Table structure for table `workflow_phases`
--

CREATE TABLE `workflow_phases` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `workflow_id` bigint(20) UNSIGNED NOT NULL,
  `index` tinyint(3) UNSIGNED NOT NULL COMMENT 'Phase number: 1, 2, 3, 4',
  `title` varchar(255) NOT NULL,
  `title_ar` varchar(255) DEFAULT NULL,
  `tags` varchar(255) DEFAULT NULL COMMENT 'Tools or key features like Rhino, STL',
  `tags_ar` varchar(255) DEFAULT NULL,
  `description` text NOT NULL,
  `description_ar` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `workflow_phases`
--

INSERT INTO `workflow_phases` (`id`, `workflow_id`, `index`, `title`, `title_ar`, `tags`, `tags_ar`, `description`, `description_ar`, `created_at`, `updated_at`) VALUES
(5, 3, 1, 'Design Brief & Specifications', 'موجز التصميم والمواصفات', 'WhatsApp • Sketch • Reference Image', 'واتساب • رسم تخطيطي • صورة مرجعية', 'You provide your design concept (photo, sketch, or sample) along with precise details: metal karat (18K-24K), estimated weights, stone information, and required sizes. We confirm the scope and delivery timeline.', 'تقدم مفهوم التصميم الخاص بك (صورة أو رسم تخطيطي أو عينة) مع تفاصيل دقيقة: عيار المعدن (18-24 قيراط)، الأوزان المقدرة، معلومات الأحجار، والأحجام المطلوبة. نؤكد النطاق والجدول الزمني للتسليم.', '2025-11-23 12:52:27', '2025-11-23 12:52:27'),
(6, 3, 2, 'High-Accuracy CAD Modeling', 'نمذجة CAD عالية الدقة', 'Rhino • MatrixGold Optimization', 'راينو • تحسين MatrixGold', 'We build a dimensionally perfect 3D model, fully optimized for casting and 3D printing. We guarantee correct metal thickness and precise geometry for stone settings and durability.', 'نبني نموذجاً ثلاثي الأبعاد مثالياً من حيث الأبعاد، محسّن بالكامل للصب والطباعة ثلاثية الأبعاد. نضمن سمك المعدن الصحيح والهندسة الدقيقة لإعدادات الأحجار والمتانة.', '2025-11-23 12:52:27', '2025-11-23 12:52:27'),
(7, 3, 3, 'Realistic Client Presentation', 'عرض واقعي للعميل', 'Hyper-Realistic Renders & 360°', 'عروض واقعية للغاية و360 درجة', 'You receive stunning, hyper-realistic images and optional turntable previews to present to your client. We handle minor modifications swiftly until the design receives final approval.', 'تتلقى صوراً مذهلة وواقعية للغاية ومعاينات دوارة اختيارية لتقديمها لعميلك. نتعامل مع التعديلات الطفيفة بسرعة حتى يحصل التصميم على الموافقة النهائية.', '2025-11-23 12:52:27', '2025-11-23 12:52:27'),
(8, 3, 4, 'Production-Ready Files', 'ملفات جاهزة للإنتاج', 'STL • 3DM • Weight Calculation', 'STL • 3DM • حساب الوزن', 'We deliver clean STL and 3DM files ready for immediate printing or molding. We provide technical support for the casting process and future adjustments to weight or size as needed.', 'نقدم ملفات STL و3DM نظيفة جاهزة للطباعة أو القولبة الفورية. نقدم الدعم الفني لعملية الصب والتعديلات المستقبلية على الوزن أو الحجم حسب الحاجة.', '2025-11-23 12:52:27', '2025-11-23 12:52:27');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `agta_awards`
--
ALTER TABLE `agta_awards`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cache`
--
ALTER TABLE `cache`
  ADD PRIMARY KEY (`key`);

--
-- Indexes for table `cache_locks`
--
ALTER TABLE `cache_locks`
  ADD PRIMARY KEY (`key`);

--
-- Indexes for table `carts`
--
ALTER TABLE `carts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `carts_user_id_foreign` (`user_id`),
  ADD KEY `carts_session_id_index` (`session_id`);

--
-- Indexes for table `cart_items`
--
ALTER TABLE `cart_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `cart_items_cart_id_foreign` (`cart_id`),
  ADD KEY `cart_items_design_id_foreign` (`design_id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `categories_slug_unique` (`slug`);

--
-- Indexes for table `designs`
--
ALTER TABLE `designs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `designs_category_id_foreign` (`category_id`);

--
-- Indexes for table `design_details`
--
ALTER TABLE `design_details`
  ADD PRIMARY KEY (`id`),
  ADD KEY `design_details_design_id_foreign` (`design_id`);

--
-- Indexes for table `digital_prototyping_features`
--
ALTER TABLE `digital_prototyping_features`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `jobs`
--
ALTER TABLE `jobs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `jobs_queue_index` (`queue`);

--
-- Indexes for table `job_batches`
--
ALTER TABLE `job_batches`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_reset_tokens`
--
ALTER TABLE `password_reset_tokens`
  ADD PRIMARY KEY (`email`);

--
-- Indexes for table `sessions`
--
ALTER TABLE `sessions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sessions_user_id_index` (`user_id`),
  ADD KEY `sessions_last_activity_index` (`last_activity`);

--
-- Indexes for table `slider_images`
--
ALTER TABLE `slider_images`
  ADD PRIMARY KEY (`id`),
  ADD KEY `slider_images_sort_order_index` (`sort_order`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- Indexes for table `workflows`
--
ALTER TABLE `workflows`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `workflow_phases`
--
ALTER TABLE `workflow_phases`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `workflow_phases_workflow_id_index_unique` (`workflow_id`,`index`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `agta_awards`
--
ALTER TABLE `agta_awards`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `carts`
--
ALTER TABLE `carts`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `cart_items`
--
ALTER TABLE `cart_items`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `designs`
--
ALTER TABLE `designs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `design_details`
--
ALTER TABLE `design_details`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `digital_prototyping_features`
--
ALTER TABLE `digital_prototyping_features`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `jobs`
--
ALTER TABLE `jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `slider_images`
--
ALTER TABLE `slider_images`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `workflows`
--
ALTER TABLE `workflows`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `workflow_phases`
--
ALTER TABLE `workflow_phases`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `carts`
--
ALTER TABLE `carts`
  ADD CONSTRAINT `carts_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `cart_items`
--
ALTER TABLE `cart_items`
  ADD CONSTRAINT `cart_items_cart_id_foreign` FOREIGN KEY (`cart_id`) REFERENCES `carts` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `cart_items_design_id_foreign` FOREIGN KEY (`design_id`) REFERENCES `designs` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `designs`
--
ALTER TABLE `designs`
  ADD CONSTRAINT `designs_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `design_details`
--
ALTER TABLE `design_details`
  ADD CONSTRAINT `design_details_design_id_foreign` FOREIGN KEY (`design_id`) REFERENCES `designs` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `workflow_phases`
--
ALTER TABLE `workflow_phases`
  ADD CONSTRAINT `workflow_phases_workflow_id_foreign` FOREIGN KEY (`workflow_id`) REFERENCES `workflows` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
